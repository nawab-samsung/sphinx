# Unit Testing and Code Coverage

Unit testing and Code Coverage are essential facets in ensuring the quality and reliability of your apps. In Tizen Studio, you can verify every unit of the code that is used to implement functional requirements and how well the test set is covering your source code or to what extent the set of test cases covers the source code. 

A unit test generally exercises the functionality of the smallest possible unit of code, which can be a method, class, or a component. In contrast, Code Coverage is a metric that helps you understand how much of your source code is tested and helps detect parts of your code that are not covered by a scenario and makes sure that the uncovered code does not cause errors at runtime. Code Coverage is measured in proportions of percentage. 
In Tizen Studio, you can run unit tests and view code coverage after every build by creating a test project alongside your main project. It helps you to quickly catch and fix regressions introduced by code changes in your app.

Tizen Studio Unit tests are based on **gtest** framework and Code Coverage is based on the **llvm-cov** tool. 
To use Tizen Unit test and coverage tool, ensure that you have your app source code available in Tizen Studio under **Project Explorer** view, and follow these steps: 

   1. [Create Unit Test Project](#create-unit-test-project)
   2. [Use Test Project](#use-test-project)
   3. [Create Unit Test Project](#create-unit-test-project)

   > [!Note]  
   > Before you run the Unit Test and Code Coverage:
   > - Ensure that you have an emulator or a connected target device in running state.
   > - If you want to try out the tool and do not have an applicable project to test, create a test project with the Project Wizard using **File> New> Tizen Project** option. For more information on creating a project, see [Creating Your First Tizen Mobile Native Application] (../../native/get-started/mobile/first-app.md).

## Create Unit Test Project

You can create a test project for the Tizen projects using the Tizen Unit Test Project wizard. The wizard provides the test project for most of the Tizen project categories. You can create test projects for Tizen native as well as Tizen Web.  
To create a test project, follow these steps:

 1. In the Tizen Studio menu, select **File > New > Other > Tizen > Tizen Native Unit Test Project**.
   
    A New Tizen Unit Test Project window appears. 
 2. Enter the **Project name**.
 3. Select the **Location**.
 4. In the **Select the Tizen Project for test** panel, select the project you want to test.
 5. Click **Finish**.
  
    ![New Tizen Unit Test Project wizard](./media/unit_test_wizard.png)

## Use Unit Test project

To use the test project, follow these steps:
  1. In the **Project Explorer** view, open the `<TEST_PROJECT_HOME>/src/<TEST_PROJECT_NAME>TestCase.cpp` file.
  2. Add a `TEST_F()` test case.

     > [!Note]
     > Each `TEST_F()` test case is independent, and if the `TEST_F()` test case is associated with a fixture class name, the test case runs based on that fixture class.
  3. Add your assertions.
    
     > [!Note]
     > The unit test tool supports basic assertions, binary comparison, and string comparison in the gtest. For more information, see [Google Test Advanced Guide](https://github.com/google/googletest/blob/master/googletest/docs/advanced.md).

## Run Unit Test project 

To run the Unit Test project and get the Unit test results and code coverage, follow these steps: 
  
  1. Select your unit test project in **Project Explorer**
  2. On the Toolbar, click**Run > Run as > Tizen Native Unit Test and Coverage**.

     **Figure: Running the test project**

     ![Run Unit Test](./media/image1.png)

After the test cases get executed, the unit test result is displayed under the **Native Unit Test Result**, and the code coverage is displayed  under **Code Coverage** as shown as follows: 

   **Figure: Test results**

   ![Test results](./media/image2.png)

   **Figure: Code Coverage**

   ![Code Coverage](./media/code_coverage1.png)

### Code Coverage Information

Tizen Studio shows the code coverage information in the editor after the application has closed. A **Code Coverage** view also opens to give a summary of the code coverage percentage for each file. 

- The code covered during the scenario has a green highlight, and the uncovered code has a red highlight:
  
  **Figure: Code Coverage results**
  ![Code Coverage result](./media/code_coverage1.png)
  
- Each row of the **Code Coverage** view can be expanded to show the function level coverage information:
  
  ![ Code Coverage result on a function level](./media/code_coverage2.png)

### Customize Unit Test Launch Configuration

The test cases can be customized for running by setting the launch options. 

To set the launch options, follow the steps:

  1. In the **Project Explorer** view, right-click the project.
  2. Select **Run > Run Configurations or Run > Debug Configurations**.
  3. Select **Tizen Native Unit Test**, and click **New**.

The name of the test project is displayed in the **Configurations** dialog box. You can control specific launch options in the **Advanced** tab:
  
  - **Run Disabled Tests**: If selected, the disabled test cases are also run.
  - **Shuffle Tests**: If selected, test cases run in random order.
  - **Generate an XML Report**: If selected, a test result XML file is generated.

## Manage Test Cases

In the **Test Explorer** view, you can launch the test cases, and check the results. If you want to open the **Test Explorer** view or update the test cases, right-click the unit test project in the **Project Explorer**, and select **Show in Test Explorer**.
When the test cases are executed, the test case states are automatically updated.

**Table: Test case states**

| Icon | Description |               
|----------------------------------------|----------------------------------------|
| ![Start icon](./media/unit_test_icon_start.png) Starting state | When you open the view for the first time, all nodes have this status, except the disabled tests. |
| ![Disabled icon](./media/unit_test_icon_disabled.png) Test is disabled | Disabled nodes are not run.              |
| ![Success icon](./media/unit_test_icon_success.png) The test has been successfully run | Test suites have this status when all their test cases have been successfully run. |
| ![Abnormal icon](./media/unit_test_icon_abnormal.png) Abnormal test suite status | ![Terminated icon](./media/unit_test_icon_terminated.png) The test was not fully performed, because it was abnormally terminated.</br>![Killed icon](./media/unit_test_icon_killed.png) The test was killed by the system because it exceeded the specified time. |

The **Test Explorer** view provides the following options:

 - **Refresh Tree**: refreshes the test case tree to reflect the linked unit test project's changes.
 - **Expand All** and **Collapse All**: expands or collapses the test case tree.
 - **Check All** and **Clear All**: checks or unchecks all the checkboxes in the tree.
 - **Check Failed**: checks failed test cases only.
 - **Run Checked**: runs checked test cases.
 - **Run Disabled Tests**: if selected, also runs the disabled test cases.
 - **Shuffle Tests**: if selected, runs test cases in random order.
 - **Generate an XML Report**: if selected, generates a test result XML file.

The **Run Disabled Tests**, **Shuffle Tests**, and **Generate an XML Report** options can be altered in the **Advanced** tab of the [Customize Launch Configuration(#customizing-the-launch-configuration).

### Example Unit Tests

The following is the test the project written in the C code, a unit test project for the C++ language is also provided. In this case, the tested function must be qualified as an extern "C" to avoid the 'undefined reference' error as demangled symbols in the error message.

There are two forms of the extern "C" declaration:

- Declare the extern "C" linkage specification in the C header file, as follows:

    ```
  #ifdef __cplusplus
  
  extern "C"
  
  { 
  
  #endif   
  
  int foo;   

  void bar();   

  #ifdef __cplusplus
  
  }
  
    #endif
   ```
 - Include the C headers in the C++ code,as follows:

   ```
 
   extern "C"
    {
     
    #include "header.h"
  
    }
  
   ```

In the following example, you will create a sample calculator project, and a test case for the `utils_round()` declared in the `utils/utils.h` header file:
 1. Create a calculator project with name **myProject**.
 2. Create a unit test project with name **myProjectTest**.
 3. Append the test method to the end of the `myProjectTest/src/myProjectTestTestCase.cpp` file, as follows:  

    ```
    TEST_F(TestSuite, utils_round)
    {
   
    double var = 3.5;
   
    /* long long utils_round(double value); */
   
    EXPECT_EQ(utils_round(var), (long long)4);
    }
    ```
4. Change the line that includes the `utils/utils.h` file, as follows:  

   ```
    #include "view/window.h"
    #include "view/main-view.h"
    extern "C"
    {
    
    #include "utils/utils.h"
    }
    #include "utils/ui-utils.h"
    ```
## Related information

- Dependencies
  - Tizen Studio 1.0 and Higher
